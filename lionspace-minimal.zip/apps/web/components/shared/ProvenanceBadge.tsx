// Re-export from ai/ProvenanceBadge for backwards compatibility
export { ProvenanceBadge } from '@/components/ai/ProvenanceBadge'
