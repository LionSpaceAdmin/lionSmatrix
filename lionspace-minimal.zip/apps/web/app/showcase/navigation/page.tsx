import { NavigationShowcase } from '@/components/navigation/NavigationShowcase';

export default function NavigationShowcasePage() {
  return <NavigationShowcase />;
}