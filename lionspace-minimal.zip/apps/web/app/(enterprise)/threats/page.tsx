export default function ThreatsPage() { return <div>Threat Monitor - TODO</div> }
