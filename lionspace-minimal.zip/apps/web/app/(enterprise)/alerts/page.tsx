export default function AlertsPage() { return <div>Alert Configuration - TODO</div> }
