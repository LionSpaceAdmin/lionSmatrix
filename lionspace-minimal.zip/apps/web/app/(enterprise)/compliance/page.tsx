export default function CompliancePage() { return <div>Compliance Dashboard - TODO</div> }
