// Courses page - TODO: Implement
