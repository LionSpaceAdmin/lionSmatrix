// Social Hub Page
// TODO: Cross-platform publishing (X/FB/TikTok/YouTube)
export default function SocialHubPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-terminal-cyan">SOCIAL HUB</h1>
      <p className="text-terminal-muted mt-2">Cross-platform publishing and management - Coming Soon</p>
    </div>
  )
}
