// Community Page
// TODO: Teams, forums, drills
export default function CommunityPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-terminal-cyan">COMMUNITY</h1>
      <p className="text-terminal-muted mt-2">Teams, forums, and training drills - Coming Soon</p>
    </div>
  )
}
