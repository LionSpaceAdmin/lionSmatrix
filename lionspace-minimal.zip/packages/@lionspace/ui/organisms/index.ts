export { default as Header } from './Header';
export { default as Footer } from './Footer';
export { default as Terminal } from './Terminal';
export { default as Dashboard } from './Dashboard';