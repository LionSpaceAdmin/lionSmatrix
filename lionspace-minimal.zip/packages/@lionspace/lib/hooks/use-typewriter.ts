import { useEffect, useRef } from 'react';

export function useTypewriter(
  element: HTMLElement | null,
  getLines: () => string[],
  speed: number = 50
) {
  const animationRef = useRef<boolean>(true);

  useEffect(() => {
    if (!element) return;

    const typewrite = async () => {
      let lineIndex = 0;
      
      while (animationRef.current) {
        const lines = getLines();
        const line = lines[lineIndex];
        const typeSpeed = speed + Math.random() * 30;
        
        // Type out the line
        for (let i = 0; i < line.length && animationRef.current; i++) {
          element.textContent = line.substring(0, i + 1);
          if (['.', ','].includes(line[i])) {
            await new Promise(res => setTimeout(res, 400));
          }
          await new Promise(res => setTimeout(res, typeSpeed));
        }
        
        await new Promise(res => setTimeout(res, 1500));
        
        // Delete the line
        for (let i = line.length; i > 0 && animationRef.current; i--) {
          element.textContent = line.substring(0, i - 1);
          await new Promise(res => setTimeout(res, 20));
        }
        
        await new Promise(res => setTimeout(res, 300));
        lineIndex = (lineIndex + 1) % lines.length;
      }
    };

    // Check for reduced motion preference
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    if (!mediaQuery.matches) {
      typewrite();
    } else {
      const lines = getLines();
      element.textContent = lines[0];
      element.classList.remove('typewriter-cursor');
    }

    return () => {
      animationRef.current = false;
    };
  }, [element, getLines, speed]);
}
