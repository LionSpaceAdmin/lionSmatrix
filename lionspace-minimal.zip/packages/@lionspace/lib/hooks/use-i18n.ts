import { useState, useCallback } from 'react';
import { translations, languages } from '@/lib/data/translations';

export function useI18n(defaultLang: string = 'en') {
  const [currentLang, setCurrentLang] = useState(defaultLang);

  const setLanguage = useCallback((lang: string) => {
    if (!translations[lang]) lang = 'en';
    setCurrentLang(lang);

    // Update document attributes
    document.documentElement.lang = lang;
    document.documentElement.dir = (lang === 'he' || lang === 'ar') ? 'rtl' : 'ltr';
    
    // Save to localStorage
    localStorage.setItem('preferredLanguage', lang);

    // Update all elements with data-i18n-key
    document.querySelectorAll('[data-i18n-key]').forEach(el => {
      const key = el.getAttribute('data-i18n-key');
      if (!key) return;

      const translation = translations[lang][key] || translations['en'][key];
      if (translation) {
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
          (el as HTMLInputElement).placeholder = translation;
        } else {
          const icon = el.firstChild && (el.firstChild.nodeType === 1) 
            ? el.firstChild.cloneNode(true) as Node 
            : null;
          el.textContent = translation;
          if (icon) {
            el.prepend(icon, " ");
          }
        }
      }
    });
  }, []);

  const t = useCallback((key: string): string => {
    return translations[currentLang][key] || translations['en'][key] || key;
  }, [currentLang]);

  return { currentLang, setLanguage, t, languages, translations };
}
