import { TranslationStrings, LanguageConfig } from '@/types/intelligence';

export const narrativeLines: Record<string, string[]> = {
  en: [
    "His following soared from ~417,000 to over 2.3 million...",
    "He acts as a 'multiplier' for Russian and Iranian propaganda.",
    "He embraced Iran's 'Axis of Resistance.'",
    "He interviewed Hamas politburo member Dr. Basem Naim.",
    "On stage in Yemen, he shouted 'Death to America.'"
  ],
  he: [
    "קהל העוקבים שלו זינק מכ-417,000 ליותר מ-2.3 מיליון...",
    "הוא משמש כ'מכפיל כוח' לתעמולה רוסית ואיראנית.",
    "הוא אימץ את 'ציר ההתנגדות' של איראן.",
    "הוא ראיין את חבר הלשכה המדינית של חמאס, ד\"ר באסם נעים.",
    "על במה בתימן, הוא צעק 'מוות לאמריקה'."
  ]
};

export const consoleLines: Record<string, string[]> = {
  en: [
    "Analyzing source…", 
    "Flag detected…", 
    "Botnet trace initiated…", 
    "Signal anomaly detected…", 
    "Coordinated amplification detected…", 
    "Evidence links compiled…"
  ],
  he: [
    "מנתח מקור…", 
    "זוהה דגל אדום…", 
    "מתחיל מעקב אחר רשת בוטים…", 
    "זוהתה אנומליה באות…", 
    "זוהתה הגברה מתואמת…", 
    "נאספו קישורי ראיות…"
  ]
};

export const translations: Record<string, TranslationStrings> = {
  en: { 
    name: "English", 
    hero_title: "Truth is pattern. AI sees it.", 
    hero_subtitle: "Join the battle for truth. Become a warrior of consciousness.", 
    hero_cta_join: "Analyze & Engage", 
    hero_cta_activate: "Activate AI Terminal",
    tab_analytics: "Analytics",
    tab_daily_brief: "Daily Brief",
    tab_evidence_log: "Evidence Log",
    tab_strategic_assessment: "Strategic Assessment",
    tab_influence_mapper: "Influence Mapper",
    tab_threat_analysis: "Threat Analysis",
    tab_news_pulse: "Real-time NewsPulse",
    tab_automations: "Automations",
    tab_osint_archive: "OSINT Archive",
    tab_campaign_generator: "Campaign Generator",
    tab_image_studio: "ImageGen Studio",
    tab_video_analysis: "Video Analysis",
    tab_audio_analysis: "Audio Analysis",
    tab_trust_verification: "Trust & Verification",
    tab_investigation: "Conversational Investigation",
    results_placeholder: "Results will appear here...",
    evidence_log_title: "Immutable Evidence Log",
    evidence_log_subtitle: "A chronological, cryptographically-secured audit trail of all intelligence findings logged in the system.",
    evidence_log_empty: "No evidence has been logged yet.",
    daily_brief_title: "Daily Intelligence Brief",
    daily_brief_subtitle: "Generate a \"ready-to-share\" intelligence brief on the top global disinformation threats from the last 24 hours.",
    daily_brief_button: "Generate Today's Brief",
    strategic_assessment_title: "Strategic Threat Assessment",
    strategic_assessment_subtitle: "Enter a high-level topic or operational area to generate a comprehensive intelligence report.",
    strategic_assessment_placeholder: "e.g., Russian influence operations in Africa, Iranian propaganda in South America...",
    strategic_assessment_button: "✨ Generate Threat Report",
    influence_mapper_title: "Dynamic Influence Mapper",
    influence_mapper_subtitle: "Enter a target and a topic to map their influence network in real-time.",
    influence_mapper_placeholder_target: "Target Entity (e.g., The Grayzone)",
    influence_mapper_placeholder_topic: "Topic/Narrative (e.g., Syria conflict)",
    influence_mapper_button: "✨ Trace Influence Network",
    threat_analysis_title: "Threat Analysis & Narrative Tracking",
    threat_analysis_subtitle: "Paste a topic or suspicious text. Get a quick analysis or a full real-time narrative report.",
    threat_analysis_placeholder: "Paste text or topic here...",
    threat_analysis_button_quick: "✨ Quick Analysis",
    threat_analysis_button_track: "✨ Track Competing Narratives"
  },
  he: { 
    name: "עברית",
    hero_title: "האמת היא תבנית. בינה מלאכותית רואה אותה.",
    hero_subtitle: "הצטרפו לקרב על האמת. הפכו ללוחמי תודעה.",
    hero_cta_join: "נתח והפעל",
    hero_cta_activate: "הפעל מסוף AI",
    tab_analytics: "אנליטיקס",
    tab_daily_brief: "תדריך יומי",
    tab_evidence_log: "יומן ראיות",
    tab_strategic_assessment: "הערכה אסטרטגית",
    tab_influence_mapper: "ממפה השפעה",
    tab_threat_analysis: "ניתוח איומים",
    tab_news_pulse: "פיד חדשות",
    tab_automations: "אוטומציות",
    tab_osint_archive: "ארכיון OSINT",
    tab_campaign_generator: "מחולל קמפיינים",
    tab_image_studio: "סטודיו תמונות",
    tab_video_analysis: "ניתוח וידאו",
    tab_audio_analysis: "ניתוח שמע",
    tab_trust_verification: "אמון ואימות",
    tab_investigation: "חקירה שיחתית",
    results_placeholder: "התוצאות יופיעו כאן...",
    evidence_log_title: "יומן ראיות בלתי ניתן לשינוי",
    evidence_log_subtitle: "נתיב ביקורת כרונולוגי ומאובטח קריפטוגרפית של כל ממצאי המודיעין שנשמרו במערכת.",
    evidence_log_empty: "טרם נשמרו ראיות ביומן.",
    daily_brief_title: "תדריך מודיעין יומי",
    daily_brief_subtitle: "הפק תדריך מודיעין \"מוכן לשיתוף\" על איומי הדיסאינפורמציה הגלובליים המובילים ב-24 השעות האחרונות.",
    daily_brief_button: "הפק את התדריך היומי"
  }
};

export const languages: Record<string, LanguageConfig> = {
  en: { 
    name: "English", 
    flag: "https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/flags/4x3/us.svg" 
  },
  he: { 
    name: "עברית", 
    flag: "https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/flags/4x3/il.svg" 
  },
  ar: { 
    name: "العربية", 
    flag: "https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/flags/4x3/sa.svg" 
  },
  ru: { 
    name: "Русский", 
    flag: "https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/flags/4x3/ru.svg" 
  },
  es: { 
    name: "Español", 
    flag: "https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/flags/4x3/es.svg" 
  },
  fr: { 
    name: "Français", 
    flag: "https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/flags/4x3/fr.svg" 
  },
  de: { 
    name: "Deutsch", 
    flag: "https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/flags/4x3/de.svg" 
  },
  zh: { 
    name: "中文", 
    flag: "https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/flags/4x3/cn.svg" 
  }
};
